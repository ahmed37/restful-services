package com.training.model;

public enum ActivitySearchType {

	SEARCH_BY_DURATION_RANGE, SEARCH_BY_DESCRIPTION;

}
